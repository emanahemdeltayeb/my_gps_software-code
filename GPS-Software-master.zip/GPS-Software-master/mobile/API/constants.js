const URI = '10.255.254.88:8000'; // CHANGE AS PER YOUR MACHINE

export default URI;